public class CarBooking
{
    private String bookingID;
    private String custName;
    private String carModel;
    private String pickupDate;
    private String returnDate;
    private int time;
    private double price;
    private int day;
    private String status;
    
    
    public CarBooking()
    {   }
    
    public CarBooking(String bID, String c, String cM, String pD,String rD, int t, double p, int d, String s ){
        this.bookingID = bID;
        this.custName = c;
        this.carModel = cM;
        this.pickupDate= pD;
        this.returnDate = rD;
        this.time = t;
        this.price = p;
        this.day = d;
        this.status = s;
    }
    
    public void setCarBooking(String bID, String c, String cM, String pD,String rD, int t, double p, int d, String s){
        this.bookingID = bID;
        this.custName = c;
        this.carModel = cM;
        this.pickupDate= pD;
        this.returnDate = rD;
        this.time = t;
        this.price = p;
        this.day = d;
        this.status = s;
    }
    
    public void setStatus (String s)
    {
        status = s;
    }
    
    public String getBookingID(){
        return bookingID;
    }
     public String getCustName(){
        return custName;
    }
     public String getCarModel(){
        return carModel;
    }
     public String getPickupDate(){
        return pickupDate;
    }
    public String getReturnDate(){
        return returnDate;
    }
    public int getTime(){
        return time;
    }
    public double getPrice(){
        return price;
    }
    public int getDay(){
        return day;
    }
        public String getStatus(){
        return status;
    }
        public String toString() {
        return "Booking ID: " + bookingID +
               "\nCustomer Name: " + custName +
               "\nCar Model: " + carModel +
               "\nPickup Date: " + pickupDate +
               "\nPickup/Return Time: " + time +
               "\nReturn Date: " + returnDate +
               "\nPrice: RM" + price +
               "\nDays Booked: " + day +
               "\nStatus: " + status + "\n";
    }
}