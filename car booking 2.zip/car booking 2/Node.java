
public class Node
{
    public CarBooking data; //refer to book obj
    public Node next; //to store address of node
    public Node(CarBooking d){
        data = d;
        next = null;
    }
}
