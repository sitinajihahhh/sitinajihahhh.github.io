import java.util.*;
import java.io.*;
import java.util.StringTokenizer;

public class QueueApp {
    public static void main(String args[]) {
        try {
            // Create the main queue to hold all bookings
            Queue theQueue = new Queue();
            CarBooking cb;

            // Open the file "CarBooking.txt" for reading
            BufferedReader br = new BufferedReader(new FileReader("CarBooking.txt"));
            Scanner sc = new Scanner(System.in);
            String record;

            // -------------------------------
            // PROCESS 1: Load bookings from file
            // -------------------------------
            // Read all records from the file and enqueue them into the queue
            while ((record = br.readLine()) != null) {
                StringTokenizer st = new StringTokenizer(record, ";");
                String bID = st.nextToken();             // Booking ID
                String c = st.nextToken();               // Customer Name
                String cM = st.nextToken();              // Car Model
                int d = Integer.parseInt(st.nextToken());// Days Booked
                String pD = st.nextToken();              // Pickup Date
                String rD = st.nextToken();              // Return Date
                int T = Integer.parseInt(st.nextToken());// Time
                double p = Double.parseDouble(st.nextToken()); // Price
                String s = st.nextToken();               // Status

                // Create a CarBooking object
                cb = new CarBooking(bID, c, cM, pD, rD, T, p, d, s);
                theQueue.enqueue(cb); // Add booking to the queue
            }

            boolean proceed = true;

            // -------------------------------
            // PROCESS 2: Add a new booking
            // -------------------------------
            while (proceed) {
                System.out.println("\nProceed with a new booking? (yes/no)");
                String response = sc.nextLine();

                if (response.equalsIgnoreCase("yes")) {
                    // Generate a new Booking ID by analyzing the last booking in the queue
                    String lastBookingID = "B0"; // Default if queue is empty
                    Queue tempQueue = new Queue();
                    while (!theQueue.isEmpty()) {
                        cb = (CarBooking) theQueue.dequeue();
                        lastBookingID = cb.getBookingID();
                        tempQueue.enqueue(cb); // Restore the queue
                    }
                    while (!tempQueue.isEmpty()) {
                        theQueue.enqueue(tempQueue.dequeue());
                    }
                    int newBookingNumber = Integer.parseInt(lastBookingID.substring(1)) + 1;
                    String newBookingID = "B" + newBookingNumber;

                    // Collect new booking details from the user
                    System.out.println("Enter Customer Name:");
                    String newCustomerName = sc.nextLine();
                    System.out.println("Enter Car Model (Toyota Vellfire, Nissan Almera, Toyota Hilux, Honda Accord, Toyota Camry):");
                    String newCarModel = sc.nextLine();
                    System.out.println("Enter Days Booked:");
                    int newDaysBooked = Integer.parseInt(sc.nextLine());
                    System.out.println("Enter Pickup Date (DD-MM-YYYY):");
                    String newPickupDate = sc.nextLine();
                    System.out.println("Enter Return Date (DD-MM-YYYY):");
                    String newReturnDate = sc.nextLine();
                    System.out.println("Enter Time in 24-hour system (HHMM):");
                    int newTime = Integer.parseInt(sc.nextLine());

                    // Set the price per day based on the car model
                    double pricePerDay = 0.0;
                    switch (newCarModel) {
                        case "Toyota Vellfire":
                            pricePerDay = 430.00;
                            break;
                        case "Nissan Almera":
                            pricePerDay = 90.00;
                            break;
                        case "Toyota Hilux":
                            pricePerDay = 170.00;
                            break;
                        case "Honda Accord":
                            pricePerDay = 143.00;
                            break;
                        case "Toyota Camry":
                            pricePerDay = 177.00;
                            break;
                        default:
                            System.out.println("Unknown car model. Please restart the process.");
                            continue; // Skip this iteration if the car model is invalid
                    }

                    // Calculate total payment for the booking
                    double totalPaymentBooking = pricePerDay * newDaysBooked;

                    // Automatically set the booking status as "Confirmed"
                    String newStatus = "Confirmed";

                    // Create a new CarBooking object with all required details
                    CarBooking newBooking = new CarBooking(newBookingID, newCustomerName, newCarModel, newPickupDate, newReturnDate, newTime, totalPaymentBooking, newDaysBooked, newStatus);

                    // Enqueue the new booking into the queue
                    theQueue.enqueue(newBooking);
                    System.out.println("\nNew booking added successfully.");
                } else if (response.equalsIgnoreCase("no")) {
                    proceed = false; // Exit the loop
                } else {
                    System.out.println("Invalid response. Please enter 'yes' or 'no'.");
                }
            }

            // -------------------------------
            // PROCESS 3: Display all bookings
            // -------------------------------
            System.out.println("\nAll bookings:");
            Queue tempQueue = new Queue(); // Temporary queue to preserve the original queue state
            while (!theQueue.isEmpty()) {
                cb = (CarBooking) theQueue.dequeue();
                System.out.println(cb.toString());
                tempQueue.enqueue(cb); // Restore the queue
            }
            while (!tempQueue.isEmpty()) {
                theQueue.enqueue(tempQueue.dequeue());
            }

            // -------------------------------
            // PROCESS 4: Count bookings for a specific car model
            // -------------------------------
            System.out.println("\nEnter the car model to count:");
            String carModelToCount = sc.nextLine();
            int count = 0;
            Queue tempQueue2 = new Queue(); // Temporary queue to preserve the original queue state

            while (!theQueue.isEmpty()) {
                cb = (CarBooking) theQueue.dequeue();
                if (cb.getCarModel().equalsIgnoreCase(carModelToCount)) {
                    count++; // Increment count if car model matches
                }
                tempQueue2.enqueue(cb); // Restore the queue
            }
            System.out.println("The car model " + carModelToCount + " appears " + count + " time(s) in the list.");

            // Restore the queue
            while (!tempQueue2.isEmpty()) {
                theQueue.enqueue(tempQueue2.dequeue());
            }

            // -------------------------------
            // PROCESS 5: Remove a booking by ID
            // -------------------------------
            System.out.println("\nEnter the Booking ID to remove:");
            String bookingIDToRemove = sc.nextLine();
            boolean removed = false;
            Queue tempQueue3 = new Queue();

            while (!theQueue.isEmpty()) {
                cb = (CarBooking) theQueue.dequeue();
                if (cb.getBookingID().equals(bookingIDToRemove)) {
                    removed = true; // Mark booking as removed
                } else {
                    tempQueue3.enqueue(cb);
                }
            }
            if (removed) {
                System.out.println("\nBooking with ID " + bookingIDToRemove + " removed successfully.");
                theQueue = tempQueue3; // Update the queue with the new state
            } else {
                System.out.println("\nBooking with ID " + bookingIDToRemove + " not found.");
            }
            
            // Continue with additional processes (best-selling model, updating status, calculating total payments, etc.)
             // Process 4: Find best-selling car model
            String bestSeller = "";
            int maxCount = 0;

            // Temporary queue to preserve the original state
            tempQueue = new Queue();
            Queue restoreQueue = new Queue();

            // Loop through the queue and count occurrences of each car model
            while (!theQueue.isEmpty()) {
                cb = (CarBooking) theQueue.dequeue();
                String carModel = cb.getCarModel();

                int currentCount = 0;
                Queue tempQueueForCounting = new Queue();
                Queue tempQueueForRestoration = new Queue();

                while (!theQueue.isEmpty()) {
                    CarBooking currentBooking = (CarBooking) theQueue.dequeue();
                    if (currentBooking.getCarModel().equals(carModel)) {
                        currentCount++;
                    }
                    tempQueueForCounting.enqueue(currentBooking);
                }

                while (!tempQueueForCounting.isEmpty()) {
                    tempQueueForRestoration.enqueue(tempQueueForCounting.dequeue());
                }

                while (!tempQueueForRestoration.isEmpty()) {
                    theQueue.enqueue(tempQueueForRestoration.dequeue());
                }

                if (currentCount > maxCount) {
                    bestSeller = carModel;
                    maxCount = currentCount;
                }

                tempQueue.enqueue(cb);
            }

            System.out.println("Best-Selling Car Model: " + bestSeller);

            while (!tempQueue.isEmpty()) {
                theQueue.enqueue(tempQueue.dequeue());
            }

            // Process 5: Calculate total payments
            double grandTotal = 0.0;
            System.out.println("\nPayments for each booking:");
            Queue tempQueue7 = new Queue();

            if (theQueue.isEmpty()) {
                System.out.println("No bookings found in the queue.");
            } else {
                while (!theQueue.isEmpty()) {
                    cb = (CarBooking) theQueue.dequeue();

                    if (cb == null) {
                        continue;
                    }

                    if (cb.getCarModel() == null || cb.getBookingID() == null || cb.getPrice() == 0.0 || cb.getDay() == 0) {
                        System.out.println("Error: Incomplete data for booking ID " + cb.getBookingID());
                        continue;
                    }

                    double price = 0.0;

                    switch (cb.getCarModel()) {
                        case "Toyota Vellfire":
                            price = 430.0;
                            break;
                        case "Nissan Almera":
                            price = 90.0;
                            break;
                        case "Toyota Hilux":
                            price = 170.0;
                            break;
                        case "Honda Accord":
                            price = 143.0;
                            break;
                        case "Toyota Camry":
                            price = 177.0;
                            break;
                        default:
                            System.out.println("Unknown car model: " + cb.getCarModel());
                            price = 0.0;
                    }
                    double totalPayment = cb.getPrice();
                    grandTotal += totalPayment;

                    System.out.println("Booking ID: " + cb.getBookingID() + ", Payment: RM" + totalPayment);
                    tempQueue7.enqueue(cb);
                }

                System.out.println("Total payment for all bookings: RM" + grandTotal);

                while (!tempQueue7.isEmpty()) {
                    theQueue.enqueue(tempQueue7.dequeue());
                }
            }

            // Process 6: Update the status of a specific booking by ID
            System.out.println("\nEnter the Booking ID to update status:");
            String bookingIDUpdated = sc.nextLine();
            System.out.println("Enter the new status for the booking:");
            String newStatus = sc.nextLine();
            boolean isUpdated = false;
            Queue updatedQueue = new Queue();

            while (!theQueue.isEmpty()) {
                cb = (CarBooking) theQueue.dequeue();
                if (cb.getBookingID().equals(bookingIDUpdated)) {
                    cb.setStatus(newStatus);
                    isUpdated = true;
                }
                updatedQueue.enqueue(cb);
            }

            if (isUpdated) {
                System.out.println("\nBooking status updated successfully!");
            } else {
                System.out.println("\nBooking ID not found.");
            }

            while (!updatedQueue.isEmpty()) {
                theQueue.enqueue(updatedQueue.dequeue());
            }

            // Display all bookings after update
            System.out.println("All bookings after status update:");
            while (!theQueue.isEmpty()) {
                cb = (CarBooking) theQueue.dequeue();
                System.out.println(cb.toString());
            }

        } catch (FileNotFoundException fnf) {
            System.out.println("Input file does not exist");
        } catch (EOFException eof) {
            System.out.println(eof.getMessage());
        } catch (IOException io) {
            System.out.println(io.getMessage());
        }
    }
}

